Vaultly - deploy

1. Go to app.netlify.com/drop
2. Drag this unzipped folder (or the zip) onto the page
3. Open the https:// link Netlify gives you and allow Camera when asked

Documents are stored in each browser (IndexedDB) per web address, and are not backed up.
